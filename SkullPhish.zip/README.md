# SkullPhish - Multi Phishing Tool

## Created by Skull (عبد الرحمن)

### Requirements:
- bash
- php
- curl
- ngrok

### Usage:
1. Run `./skullphish.sh`
2. Choose target site
3. Share the generated ngrok link with target
4. Wait for victim to submit info

### Disclaimer:
This tool is for educational purposes only. Use responsibly.
